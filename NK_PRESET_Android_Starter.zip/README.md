# NK PRESET Android WebView starter

This is a starter Android project for building a WebView app with AdMob through GitHub Actions.

## Important before production
- The project deliberately uses Google's official **test ad unit IDs** for banner and rewarded ads. This prevents accidental live-ad clicks during development.
- The AdMob App ID in AndroidManifest is the App ID supplied by the project owner.
- The supplied production Banner, Rewarded, and Interstitial unit IDs are NOT activated in this starter. Replace test unit IDs only after testing, app setup, consent/privacy checks, and AdMob policy review.
- Interstitial ID is recorded but no interstitial placement is implemented yet.
- The website must call `window.NKAds.showRewarded()` to open a native rewarded ad. After a completed reward, the app dispatches `nk-reward-earned`; on dismissal without reward it dispatches `nk-reward-not-earned`; on error it dispatches `nk-ad-error`.
- The website must handle those events and only unlock after receiving `nk-reward-earned`. For two ad steps, call `showRewarded()` again after the first earned event. Do not unlock from a client-only event in a production app without server-side verification.

## Build with GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root (not the enclosing folder).
3. Open Actions and run **Build NK PRESET APK**, or push to `main`.
4. Download the `NK-PRESET-debug-APK` artifact from the completed workflow run.

The debug APK is for testing. A release APK/AAB needs signing before distribution.
