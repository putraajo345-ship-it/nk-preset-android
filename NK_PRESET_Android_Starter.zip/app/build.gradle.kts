plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.nkpreset.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.nkpreset.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
