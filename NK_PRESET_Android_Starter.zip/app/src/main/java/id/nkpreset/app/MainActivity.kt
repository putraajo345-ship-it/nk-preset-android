package id.nkpreset.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.AdError

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var adContainer: LinearLayout
    private var rewardedAd: RewardedAd? = null
    private var rewardCallbackPending = false

    // Google test ad unit IDs are used until you deliberately switch to production IDs.
    private val bannerId = "ca-app-pub-3940256099942544/9214589741"
    private val rewardedId = "ca-app-pub-3940256099942544/5224354917"
    private val interstitialId = "ca-app-pub-3940256099942544/1033173712"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {
            runOnUiThread {
                loadBanner()
                loadRewarded()
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(NKBridge(), "NKAds")
        }
        adContainer = LinearLayout(this)
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(adContainer, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        webView.loadUrl("https://nk-preset-flow.base44.app")
    }

    private fun loadBanner() {
        val adView = AdView(this)
        adView.adUnitId = bannerId
        adView.setAdSize(AdSize.BANNER)
        adContainer.removeAllViews()
        adContainer.addView(adView)
        adView.loadAd(AdRequest.Builder().build())
    }

    private fun loadRewarded() {
        RewardedAd.load(this, rewardedId, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            })
    }

    private fun showRewarded() {
        val ad = rewardedAd
        if (ad == null) {
            runOnUiThread {
                Toast.makeText(this, "Iklan belum siap. Coba lagi sebentar.", Toast.LENGTH_SHORT).show()
                webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('nk-ad-error'))", null)
            }
            loadRewarded()
            return
        }
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                if (earned) {
                    webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('nk-reward-earned'))", null)
                } else {
                    webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('nk-reward-not-earned'))", null)
                }
                loadRewarded()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                rewardedAd = null
                webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('nk-ad-error'))", null)
                loadRewarded()
            }
        }
        ad.show(this) { earned = true }
    }

    inner class NKBridge {
        @JavascriptInterface
        fun showRewarded() {
            runOnUiThread { showRewarded() }
        }
    }

    @Suppress("unused")
    private fun unusedInterstitialReference() { val id = interstitialId }

    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
